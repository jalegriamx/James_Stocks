npm install yahoo-finance2 --save
const express = require('express');
const yahooFinance = require('yahoo-finance2').default;

const app = express();
const port = 3000;

// Enable CORS for development
app.use((req, res, next) => {
    res.header('Access-Control-Allow-Origin', '*');
    res.header('Access-Control-Allow-Headers', 'Origin, X-Requested-With, Content-Type, Accept');
    next();
});

// Fetch stock fundamental data
app.get('/api/stock/:ticker', async (req, res) => {
    const ticker = req.params.ticker;
    try {
        // Fetch summary data from Yahoo Finance
        const quoteSummary = await yahooFinance.quoteSummary(ticker, { modules: ['summaryDetail', 'financialData', 'defaultKeyStatistics'] });

        // Extract relevant data
        const summary = quoteSummary.summaryDetail;
        const financialData = quoteSummary.financialData;
        const statistics = quoteSummary.defaultKeyStatistics;

        const stockData = {
            ticker: ticker,
            price: summary.previousClose,
            peRatio: statistics.trailingPE,
            pbRatio: statistics.priceToBook,
            pegRatio: statistics.pegRatio,
            dividendYield: summary.dividendYield * 100,
            roe: financialData.returnOnEquity * 100,
            debtToEquity: financialData.debtToEquity
        };

        res.json(stockData);
    } catch (error) {
        console.error(error);
        res.status(500).json({ error: 'Failed to fetch stock data' });
    }
});

app.listen(port, () => {
    console.log(`Server running on http://localhost:${port}`);
});
document.getElementById('stockForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    
    let ticker = document.getElementById('ticker').value.trim().toUpperCase();
    
    if (!ticker) {
        alert('Please enter a valid stock ticker.');
        return;
    }

    try {
        // Fetch stock data from the backend API
        const response = await fetch(`http://localhost:3000/api/stock/${ticker}`);
        const stockData = await response.json();

        if (stockData.error) {
            alert(stockData.error);
            return;
        }

        // Display the stock data in the results section
        const resultSection = document.getElementById('resultSection');
        resultSection.innerHTML = `
            <h2>${ticker} Analysis</h2>
            <p><strong>Price:</strong> $${stockData.price}</p>
            <p><strong>P/E Ratio:</strong> ${stockData.peRatio || 'N/A'}</p>
            <p><strong>P/B Ratio:</strong> ${stockData.pbRatio || 'N/A'}</p>
            <p><strong>PEG Ratio:</strong> ${stockData.pegRatio || 'N/A'}</p>
            <p><strong>Dividend Yield:</strong> ${stockData.dividendYield || 'N/A'}%</p>
            <p><strong>Return on Equity (ROE):</strong> ${stockData.roe || 'N/A'}%</p>
            <p><strong>Debt-to-Equity Ratio:</strong> ${stockData.debtToEquity || 'N/A'}</p>
        `;

        // Chart.js example for visualizing stock data
        const ctx = document.createElement('canvas');
        resultSection.appendChild(ctx);

        new Chart(ctx, {
            type: 'bar',
            data: {
                labels: ['P/E Ratio', 'P/B Ratio', 'PEG Ratio', 'Dividend Yield', 'ROE', 'Debt-to-Equity'],
                datasets: [{
                    label: `${ticker} Stock Fundamentals`,
                    data: [stockData.peRatio, stockData.pbRatio, stockData.pegRatio, stockData.dividendYield, stockData.roe, stockData.debtToEquity],
                    backgroundColor: ['rgba(54, 162, 235, 0.2)'],
                    borderColor: ['rgba(54, 162, 235, 1)'],
                    borderWidth: 1
                }]
            },
            options: {
                scales: {
                    y: {
                        beginAtZero: true
                    }
                }
            }
        });

    } catch (error) {
        console.error('Error fetching stock data:', error);
        alert('Failed to fetch stock data. Please try again.');
    }
});
